package Pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class QT_activity {
	
	public WebDriver driver;
	public QT_activity(WebDriver driver)
	{
		
		this.driver=driver;
	}
	
	By name=By.xpath("//body/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/h5[1]");
	
	
	
	
	
	public WebElement name()
	 {
		return driver.findElement(name);
		 
	 }
	
}
