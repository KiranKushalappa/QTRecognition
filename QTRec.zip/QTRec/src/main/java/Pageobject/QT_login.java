package Pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import resource.base;

public class QT_login extends base {
	
	
	
	public WebDriver driver;
	public QT_login(WebDriver driver)
	{
		
		this.driver=driver;
	}
	
	By uname=By.xpath("//input[@name='username']");
	 By pword=By.xpath("//input[@name='pass']");
	 By loginbutton=By.xpath("//button[contains(text(),'Login')]");
	 By topbody = By.xpath("//body/div[1]");
		By lowbody = By.xpath("//body");
		By loginbody=By.xpath("//button[contains(text(),'Login')]");
	//1.1.1
	public WebElement getusername()
	 {
		return driver.findElement(uname);
		 
	 }
	
	public WebElement getpassword()
	 {
		return driver.findElement(pword);
		 
	 }
	
	public WebElement getloginbutton()
	 {
		return driver.findElement(loginbutton);
		 
	 }
	public WebElement topbody() {
		return driver.findElement(topbody);
	}
	
	public WebElement lowbody() {
		return driver.findElement(lowbody);
	}
	
	public WebElement loginbody() {
		return driver.findElement(loginbody);
	}
}
