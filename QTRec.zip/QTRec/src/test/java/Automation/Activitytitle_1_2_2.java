package Automation;

import java.io.IOException;

//import org.openqa.selenium.WebDriver;
import org.testng.Assert;
//import org.testng.annotations.BeforeTest;
//import org.testng.annotations.DataProvider;
//import org.testng.annotations.Test;
import org.testng.annotations.Test;

import resource.base;

public class Activitytitle_1_2_2 extends base{

	
	 @Test
	 public void activitytitle() throws IOException
		{
		 login_details();
					
Assert.assertEquals(driver.getTitle(), "QTRecognition");
driver.close();
}
}