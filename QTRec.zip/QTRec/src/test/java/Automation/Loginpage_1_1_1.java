package Automation;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pageobject.QT_login;
import resource.base;


public class Loginpage_1_1_1 extends base{
	
		
	
	
	 @Test(dataProvider="getData")
	
	public void basePageNavigation(String username, String password) throws IOException 
	{
		 driver=initializeDriver();
			QT_login l = new QT_login(driver);
			l.getusername().sendKeys(username);
			l.getpassword().sendKeys(password);
			l.getloginbutton().click();
		    Assert.assertEquals(driver.getCurrentUrl(), "https://qtrecognition.testqtwiz.com/Activity.php");
		   // log1.info("Login successful");
		   // driver.close();
		  //1.1.2 Application title should be displayed as “QTRecognition”
			Assert.assertEquals(driver.getTitle(), "QTRecognition");
			
			driver.close();
	//1.1.1 
}
	
	@DataProvider
	public Object[][] getData()
	{
		Object[][] data = new Object[1][2];
		data[0][0]="kushalappa.pa@qualitestgroup.com";
		data[0][1]="P@ssw0rd";
		
		
		
		
		
		
		return data;
		
		
	}
}
