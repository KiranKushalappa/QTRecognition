package Automation;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pageobject.QT_login;
import resource.base;

public class Logintitle_1_1_2 extends base{

	 @Test	
	public void title() throws IOException 
	{	 
		 driver=initializeDriver();			
			Assert.assertEquals(driver.getTitle(), "QTRecognition");
		System.out.println(driver.getTitle());
		driver.close();
}

}
