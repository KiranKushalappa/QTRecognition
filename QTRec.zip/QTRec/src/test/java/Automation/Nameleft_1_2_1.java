package Automation;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pageobject.QT_activity;
import Pageobject.QT_login;
import Pageobject.QT_others;
import resource.base;

public class Nameleft_1_2_1 extends base{

	 @Test	
	public void title() throws IOException 
	{	 
		 login_details();
		 QT_activity a=new QT_activity(driver);
		String lname= a.name().getText();
		System.out.println(lname);
		Assert.assertEquals(driver.getTitle(), "QTRecognition");
		System.out.println(driver.getTitle());
		driver.close();
}

}
 