package Automation;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pageobject.QT_login;
import Pageobject.QT_others;
import Pageobject.QT_searchkudo;
import Pageobject.QT_sendkudo;
import resource.base;

public class count_1_6_4 extends base{

	 @Test	
	public void Activepagesndkudo() throws IOException, AWTException, InterruptedException 
	{	 
				login_details();
				
				QT_others o=new QT_others(driver);
				String c1=o.Kudocnt().getText();
				System.out.println(c1);
				o.getsendkudo().click();
				o.getemailid().click();
				o.getemailid().sendKeys("Kushalappa Pa (kushalappa.pa@qualitestgroup.com)");
				o.getkudo1().click();
				o.getcomment().sendKeys("goodjob");
				o.getkudosnd().click();
				Thread.sleep(1000);
				o.cancel().click();
				o.getkudofromme().click();
				Thread.sleep(3000);
				String c2=o.Kudocnt().getText();
				Assert.assertNotEquals(c1, c2);
				
				
				driver.close();
			     
			
				
				
	}		       
				
	}			



