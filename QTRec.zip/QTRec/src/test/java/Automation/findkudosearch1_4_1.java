package Automation;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pageobject.QT_login;
import Pageobject.QT_searchkudo;
import Pageobject.QT_sendkudo;
import resource.base;

public class findkudosearch1_4_1 extends base{

	 @Test	
	public void Activepagesndkudo() throws IOException, AWTException 
	{	 
				login_details();
				QT_searchkudo seakudo=new QT_searchkudo(driver);
			WebElement search=	seakudo.getsearchkudo();
			if(search.isDisplayed())
			{
				System.out.println("Kudo search option is displayed");
			}
				else
				{
					System.out.println("kudo search option is not displayed");
				}
			Assert.assertEquals(true, search.isDisplayed());
			driver.close();
			}
				
				
				
				
}


