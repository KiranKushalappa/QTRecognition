package Automation;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pageobject.QT_login;
import Pageobject.QT_sendkudo;
import resource.base;

public class kudoresend_1_3_5 extends base{

	 @Test	
	public void Activepagesndkudo() throws IOException, AWTException 
	{	 
				login_details();
				QT_sendkudo sk =new QT_sendkudo(driver);
				sk.getresndkudo().click();
				/*autopopulateemailid*/
				String CLbox =sk.getemailid().getAttribute("value");
	              if(CLbox.isEmpty())
	              {
	                     System.out.println("email id is not autopopulated ");
	              }
	              else
	              {
	                     System.out.println("email id is autopopulated");
	              }
				 
	              driver.close();
			}

}


