package Automation;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pageobject.QT_login;
import Pageobject.QT_others;
import Pageobject.QT_searchkudo;
import Pageobject.QT_sendkudo;
import resource.base;

public class kudosfromme_1_6_1 extends base{

	 @Test	
	public void Activepagesndkudo() throws IOException, AWTException, InterruptedException 
	{	 
				login_details();
				QT_others o=new QT_others(driver);
				o.getkudofromme().click();
				String fromme= o.fromname().getText();
				 System.out.println(fromme);
				
			 Assert.assertEquals(fromme,prop.getProperty("name"));
			 System.out.println("user is able to see kudos sent from him to other employees");
			 driver.close();
				 
				
				}
				
				
				
			  
			     
			
				
				
				       
				
	}			



