package Automation;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pageobject.QT_login;
import Pageobject.QT_searchkudo;
import Pageobject.QT_sendkudo;
import resource.base;

public class namesearch_1_4_2 extends base{

	 @Test	
	public void Activepagesndkudo() throws IOException, AWTException, InterruptedException 
	{	 
				login_details();
				QT_searchkudo seakudo=new QT_searchkudo(driver);
			     seakudo.getsearchkudo().click();
			     seakudo.getsearchname().click();
			     seakudo.getsearchname().sendKeys("Kushalappa P A");
			     Robot m =new Robot();
				 m.keyPress(KeyEvent.VK_DOWN);
				 m.keyPress(KeyEvent.VK_ENTER);
			
				 Thread.sleep(3000);
				 seakudo.getselectname().click();
			     
			
				 driver.close();
				
				       
				
	}			
}


