package Automation;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pageobject.QT_login;
import Pageobject.QT_others;
import Pageobject.QT_sendkudo;
import resource.base;

public class samekudos_1_6_5 extends base{

	 @Test	
	public void Activepagesndkudo() throws IOException, AWTException, InterruptedException 
	{	 
				login_details();
				
				
				
				QT_others o=new QT_others(driver);
				o.getsendkudo().click();
				//o.getemailid().click();
				o.getemailid().sendKeys("Kushalappa Pa (kushalappa.pa@qualitestgroup.com)");
				o.getkudo1().click();
				o.getcomment().sendKeys("goodjob");
				o.getkudosnd().click();
				Thread.sleep(1000);
				o.cancel().click();
				o.getkudofromme().click();
				Thread.sleep(3000);
				String x1=o.fromname().getText();
				System.out.println(x1);
				String x2=o.toname().getText();
				System.out.println(x2);
				//Assert.assertEquals(x1, x2);
				Assert.assertNotEquals(x1, x2);
				
				
				
				 
				driver.close();
				
			}

}


