package Automation;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pageobject.QT_login;
import Pageobject.QT_searchkudo;
import Pageobject.QT_sendkudo;
import resource.base;

public class verifysearch_1_4_3 extends base{
	public static Logger log=LogManager.getLogger(base.class.getName());

	 @Test	
	public void Activepagesndkudo() throws IOException, AWTException, InterruptedException 
	{	 
				login_details();
				QT_searchkudo seakudo=new QT_searchkudo(driver);
			     seakudo.getsearchkudo().click();
			     seakudo.getsearchname().click();
			     seakudo.getsearchname().sendKeys("Kushalappa");
			     Robot m =new Robot();
				 m.keyPress(KeyEvent.VK_DOWN);
				 m.keyPress(KeyEvent.VK_ENTER);
			
				 Thread.sleep(3000);
				 seakudo.getselectname().click();
				 
				 String sch= seakudo.getpostsearch().getText();
				 System.out.println(sch);
					if(sch.contains("Kushalappa")) {
						 System.out.println("PASS: results are successfully displayed");
					}
					else {
						 System.out.println("FAIL:results are not displayed");
					}
			     
			
					driver.close();
				
				       
				
	}			
}


