package Pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import resource.base;

public class QT_others extends base {
	
	 
	
	
	public WebDriver driver;
	public QT_others(WebDriver driver)
	{
		
		this.driver=driver;
	}

	By kudofromme = By.xpath("//span[contains(text(),'Kudos from me')]");
	By fromname = By.xpath("//body[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/h5[1]/b[1]");
	
	By toname = By.xpath("//body[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/h5[1]/b[2]");
	By kudotome = By.xpath("//span[contains(text(),'Kudos to me')]");
	By kudocount = By.xpath("//h5[@id='todayCount']");
	By sndkudo=By.xpath("//body/nav[1]/div[1]/div[1]/div[2]/a[1]/i[1]");
	By emailid=By.xpath("//input[@id='email_address']");
	By firstkudo=By.xpath("//body/div[@id='myModal']/div[1]/div[1]/form[1]/div[2]/div[3]/div[1]/div[1]/div[1]");
	By cancel=By.xpath("//button[contains(text(),'Cancel')]");
	By comment=By.cssSelector(" #comment");
	By activityclick=By.xpath("//button[contains(text(),'Cancel')]");
	
	By kudosnd=By.xpath("//button[contains(text(),'Send')]");
	public WebElement getkudofromme()
	{
		return driver.findElement(kudofromme);
	}
	
	public WebElement fromname()
	{
		return driver.findElement(fromname);
	}
	
	public WebElement toname()
	{
		return driver.findElement(toname);
	}
	
	public WebElement Kudotome()
	{
		return driver.findElement(kudotome);
	}
	
	public WebElement Kudocnt()
	{
		return driver.findElement(kudocount);
	}
	
	public WebElement getsendkudo()
	 {
		return driver.findElement(sndkudo);
		 
	 }
	public WebElement getemailid()
	 {
		return driver.findElement(emailid);
		 
	 }
	public WebElement getkudo1()
	 {
		return driver.findElement(firstkudo);
		 
	 }
	
	public WebElement getcomment()
	 {
		return driver.findElement(comment);
		 
	 }
	public WebElement getkudosnd()
	 {
		return driver.findElement(kudosnd);
		 
	 }
	public WebElement cancel()
	 {
		return driver.findElement(cancel);
		 
	 }
	public WebElement activityclick()
	 {
		return driver.findElement(activityclick);
		 
	 }
	
}
