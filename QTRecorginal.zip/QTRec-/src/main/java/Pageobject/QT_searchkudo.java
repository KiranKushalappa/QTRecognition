package Pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import resource.base;

public class QT_searchkudo extends base {
	
	 
	
	
	public WebDriver driver;
	public QT_searchkudo(WebDriver driver)
	{
		
		this.driver=driver;
	}

	By kudosearch=By.xpath("//span[contains(text(),'Kudos Search')]");
	By searchname=By.cssSelector("#s_e_add");
	By selectname=By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[1]/button[1]");
	By postsearch=By.xpath("//body[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/h5[1]/b[2]");
	
	
	//1.1.1
	public WebElement getsearchkudo()
	 {
		return driver.findElement(kudosearch);
		 
	 }
	public WebElement getsearchname()
	 {
		return driver.findElement(searchname);
		 
	 }
	public WebElement getselectname()
	 {
		return driver.findElement(selectname);
		 
	 }
	public WebElement getpostsearch()
	 {
		return driver.findElement(postsearch);
		 
	 }
	
	
	
	
}
