package Automation;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.testng.Assert;

import org.testng.annotations.Test;

import Pageobject.QT_login;
import resource.base;


public class Logincolor_1_1_3 extends base{
	public static Logger log=LogManager.getLogger(base.class.getName());

	
		
		@Test
		public void gold() throws IOException 
		{
			driver=initializeDriver();
			
			QT_login l=new QT_login(driver);
			WebElement TB = l.topbody();
			String G=TB.getCssValue("background-color");
		    String GOLD=Color.fromString(G).asHex();
		    Assert.assertEquals( "#FECC160",GOLD);
		   log.info(GOLD); 
		   driver.close();
			
		}
		@Test
		public void white() throws IOException {
			driver=initializeDriver();
			QT_login l=new QT_login(driver);
		
			WebElement LB = l.lowbody();	
			String W=LB.getCssValue("background-color");
			 String WHITE=Color.fromString(W).asHex();
			Assert.assertEquals( "#939598",WHITE);
			log.info(WHITE);
			// log.info(WHITE);
			driver.close();
			
		}
		@Test
		public void navy() throws IOException {
			driver=initializeDriver();
			QT_login l=new QT_login(driver);
			 
			WebElement Log = l.loginbody();
			String N=Log.getCssValue("background-color");
			 String NAVY=Color.fromString(N).asHex();
			Assert.assertEquals("#2a2559",NAVY);
			log.info(NAVY);
			driver.close();
			
		}
	
	}

