package Automation;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pageobject.QT_login;
import resource.base;


public class Loginpage_1_1_1 extends base{
	public static Logger log=LogManager.getLogger(base.class.getName());
	
@BeforeTest
	
	public void validlogin() throws IOException, InterruptedException 
	{
		 driver=initializeDriver();
		 log.info("Driver initilized");
			QT_login l = new QT_login(driver);
			l.getusername().sendKeys("kushalappa.pa@qualitestgroup.com");
			l.getpassword().sendKeys("P@ssw0rd");
			l.getloginbutton().click();
			
		  //Verification of title
			Assert.assertEquals(driver.getTitle(), "QTRecognition");
			System.out.println(driver.getTitle());
			log.info("the tittle page is: QTRecognition");
			driver.close();
}
	
	 @Test

		public void invalid() throws IOException, InterruptedException 
		{
			 driver=initializeDriver();
			 log.info("Driver initilized");
				QT_login l = new QT_login(driver);
				l.getusername().sendKeys("kushalappa.pa@qualite");
				l.getpassword().sendKeys("P@ss");
				l.getloginbutton().click();
				
				
				// verify invalid text message
				String invalid=driver.switchTo().alert().getText();
				System.out.println(invalid);
				driver.switchTo().alert().accept();
				driver.close();
	}
		
	
	
	
	
		
		
	
}
