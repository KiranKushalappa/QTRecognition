package Automation;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pageobject.QT_login;
import Pageobject.QT_sendkudo;
import resource.base;

public class resendkudo_1_5_1 extends base{
	public static Logger log=LogManager.getLogger(base.class.getName());

	 @Test	
	public void Activepagesndkudo() throws IOException, AWTException 
	{	 
				login_details();
				QT_sendkudo sk =new QT_sendkudo(driver);
				sk.getresndkudo().click();
				/*autopopulateemailid*/
				String CLbox =sk.getemailid().getAttribute("value");
	              if(CLbox.isEmpty())
	              {
	                    log.info("email id is not autopopulated ");
	                    System.out.println("email id is not autopopulated ");
	              }
	              else
	              {
	                     log.info("email id is autopopulated");
	                     System.out.println("email id is autopopulated ");
	              }
				//selcecting kudos
	              sk.getkudo1().click();  
	              System.out.println("user clicked on first kudo");
	              //writting comments
					 sk.getcomment().sendKeys("goodjob");
					 System.out.println("user commented good job");
					 //click on snd kudos
					 sk.getkudosnd().click();
					 
					driver.close();
			}

}


