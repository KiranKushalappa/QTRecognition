package Automation;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pageobject.QT_login;
import Pageobject.QT_sendkudo;
import resource.base;

public class sendkudo_1_3_1 extends base{
	public static Logger log=LogManager.getLogger(base.class.getName());
	

	 @Test	
	public void Activepagesndkudo() throws IOException, AWTException, InterruptedException 
	{	 
				login_details();
				//User should be able to send kudos form Activity page
				QT_sendkudo sk =new QT_sendkudo(driver);
				sk.getsendkudo().click();
				System.out.println("user clicked on send kudos");
				//User should be able to select Qualitest employee email address from email ID field by entering the names / email id
				sk.getemailid().click();
				sk.getemailid().sendKeys("kushal");
				
				
				Robot m=new Robot();
			     m.keyPress(KeyEvent.VK_DOWN); 
			     m.keyPress(KeyEvent.VK_DOWN);
				 m.keyPress(KeyEvent.VK_ENTER);
				 System.out.println("user is able to select qualitest employee email id");
				
				 //User should write citation for Kudos sent
				 sk.getkudo1().click();  
				 sk.getcomment().sendKeys("goodjob");
				 sk.getkudosnd().click();
				 System.out.println("user clicked on send kudos");
					Thread.sleep(10000);
					String text=sk.textcheck().getText();
					
					System.out.println(text);
				
					String actual="Kudos sent sucessfull.";
					Assert.assertEquals( text,actual);
				 
				driver.close();
				
			}
	 //Kudos without citation are not allowed
	 @Test	
		public void Activepagesndkudo1() throws IOException, AWTException, InterruptedException 
		{	 
					login_details();
					QT_sendkudo sk =new QT_sendkudo(driver);
					sk.getsendkudo().click();
					sk.getemailid().click();
					sk.getemailid().sendKeys("kushal");
					
					
					Robot m=new Robot();
				     m.keyPress(KeyEvent.VK_DOWN);
				     m.keyPress(KeyEvent.VK_DOWN);
					 m.keyPress(KeyEvent.VK_ENTER);
					 
					sk.getkudo1().click();
					sk.getcomment().sendKeys("");
					sk.getkudosnd().click();
					Thread.sleep(1000);
					String text=sk.textcheck().getText();
					
					System.out.println(text);//if comments not entered
					log.info("comments not entered");
					String actual="Please enter any comment.";
					Assert.assertEquals(actual, text);
					
					
					
					
					
					driver.close();
					
				}
	 @Test	
		public void Activepagesndkudo11() throws IOException, AWTException 
		{	 
					login_details();
					QT_sendkudo sk =new QT_sendkudo(driver);
					sk.getresndkudo().click();
					/*autopopulateemailid*/
					String CLbox =sk.getemailid().getAttribute("value");
		              if(CLbox.isEmpty())
		              {
		                    log.info("email id is not autopopulated ");
		                    System.out.println("email id is not autopopulated ");
		              }
		              else
		              {
		                     log.info("email id is autopopulated");
		                     System.out.println("email id is autopopulated ");
		              }
					 
		              driver.close();
				}
	 @Test	
		public void Activepagesndkudo3() throws IOException, AWTException, InterruptedException 
		{	 
					login_details();
					QT_sendkudo sk =new QT_sendkudo(driver);
					sk.getsendkudo().click();
					sk.getemailid().click();
					sk.getemailid().sendKeys("kushal");
					
					
					Robot m=new Robot();
				     m.keyPress(KeyEvent.VK_DOWN);
				     m.keyPress(KeyEvent.VK_DOWN);
					 m.keyPress(KeyEvent.VK_ENTER);
					 
					sk.getkudo1().click();
					sk.getkudo2().click();
					sk.getcomment().sendKeys("great");
					sk.getkudosnd().click();
					Thread.sleep(12000);
					String text=sk.textcheck().getText();
					System.out.println("when clicked 2 kudos");
					System.out.println(text);//if comments not entered
					//log.info("comments not entered");
					String actual="Please select 1 kudo.";
				Assert.assertEquals(text, actual);
					
					
					
					
					
					driver.close();
					
				}
	 
	 

}


