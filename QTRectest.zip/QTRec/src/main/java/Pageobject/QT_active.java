package Pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import resource.base;

public class QT_active extends base {
	
	
	
	public WebDriver driver;
	public QT_active(WebDriver driver)
	{
		
		this.driver=driver;
	}
	
	By name=By.xpath("//body/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/h5[1]");
	By image=By.xpath("//img[@alt='Sample Image']");
	 
	public WebElement name()
	 {
		return driver.findElement(name);
		 
	 }
	public WebElement image()
	 {
		return driver.findElement(image);
		 
	 }
	
	
}
