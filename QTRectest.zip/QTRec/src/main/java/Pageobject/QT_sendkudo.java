package Pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import resource.base;

public class QT_sendkudo extends base {
	
	 
	
	
	public WebDriver driver;
	public QT_sendkudo(WebDriver driver)
	{
		
		this.driver=driver;
	}

	By sndkudo=By.xpath("//body/nav[1]/div[1]/div[1]/div[2]/a[1]/i[1]");
	By emailid=By.xpath("//input[@id='email_address']");
	By firstkudo=By.xpath("//body/div[@id='myModal']/div[1]/div[1]/form[1]/div[2]/div[3]/div[1]/div[1]/div[1]");
	By secondkudo=By.xpath("//body/div[@id='myModal']/div[1]/div[1]/form[1]/div[2]/div[3]/div[2]/div[1]/div[1]");
	By comment=By.cssSelector(" #comment");
	
	By kudosnd=By.xpath("//button[contains(text(),'Send')]");
	By resendkudo=By.xpath("//body/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/h5[1]/small[1]/a[1]/i[1]");
	
	
	//1.1.1
	public WebElement getsendkudo()
	 {
		return driver.findElement(sndkudo);
		 
	 }
	public WebElement getemailid()
	 {
		return driver.findElement(emailid);
		 
	 }
	public WebElement getkudo1()
	 {
		return driver.findElement(firstkudo);
		 
	 }
	public WebElement getkudo2()
	 {
		return driver.findElement(secondkudo);
		 
	 }
	public WebElement getcomment()
	 {
		return driver.findElement(comment);
		 
	 }
	public WebElement getkudosnd()
	 {
		return driver.findElement(kudosnd);
		 
	 }
	public WebElement getresndkudo()
	 {
		return driver.findElement(resendkudo);
		 
	 }
	
	
	
}
