package Automation;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.testng.Assert;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pageobject.QT_login;
import resource.base;


public class Loginpage_1_1_1 extends base{
	public static Logger log=LogManager.getLogger(base.class.getName());
	
	 @Test(dataProvider="getData")
	
	public void basePageNavigation(String username, String password) throws IOException, InterruptedException 
	{
		 driver=initializeDriver();
		 log.info("Driver initilized");
			QT_login l = new QT_login(driver);
			l.getusername().sendKeys(username);
			l.getpassword().sendKeys(password);
			l.getloginbutton().click();
			
		  //Verification of title
			Assert.assertEquals(driver.getTitle(), "QTRecognition");
			System.out.println(driver.getTitle());
			log.info("the tittle page is: QTRecognition");
			driver.close();
}
	
	@DataProvider
	public Object[][] getData()
	{
		Object[][] data = new Object[1][2];
		data[0][0]="kushalappa.pa@qualitestgroup.com";
		data[0][1]="P@ssw0rd";
		
		
		
		
		
		return data;
		
		
	}
}
