package Automation;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pageobject.QT_login;
import Pageobject.QT_searchkudo;
import Pageobject.QT_sendkudo;
import resource.base;

public class findkudosearch1_4_1 extends base{
	public static Logger log=LogManager.getLogger(base.class.getName());
//User should be able to find option kudos search form Activity page
	 @Test	
	public void Activepagesndkudo() throws IOException, AWTException 
	{	 
				login_details();
				QT_searchkudo seakudo=new QT_searchkudo(driver);
			WebElement search=	seakudo.getsearchkudo();
			if(search.isDisplayed())
			{
				System.out.println("Kudo search option is displayed");
				log.info("Kudo search option is displayed");
			}
				else
				{
					System.out.println("Kudo search option is not displayed");
					log.info("Kudo search option is not displayed");
				}
			Assert.assertEquals(true, search.isDisplayed());
			driver.close();
			}
	 
	 //User can search kudos sent any other user by name or email id

	 @Test	
		public void Activepagesndkudo1() throws IOException, AWTException, InterruptedException 
		{	 
					login_details();
					QT_searchkudo seakudo=new QT_searchkudo(driver);
				     seakudo.getsearchkudo().click();
				     seakudo.getsearchname().click();
				     seakudo.getsearchname().sendKeys("Kushalappa P A");
				     Robot m =new Robot();
					 m.keyPress(KeyEvent.VK_DOWN);
					 m.keyPress(KeyEvent.VK_ENTER);
				
					 Thread.sleep(3000);
					 seakudo.getselectname().click();
				     
				
					 driver.close();
			       
					
		}	
	 //Post successful search user should be able to see the list of kudos sent form or to the user
	 @Test	
		public void Activepagesndkudo11() throws IOException, AWTException, InterruptedException 
		{	 
					login_details();
					QT_searchkudo seakudo=new QT_searchkudo(driver);
				     seakudo.getsearchkudo().click();
				     seakudo.getsearchname().click();
				     seakudo.getsearchname().sendKeys("Kushalappa");
				     Robot m =new Robot();
					 m.keyPress(KeyEvent.VK_DOWN);
					 m.keyPress(KeyEvent.VK_ENTER);
				
					
					 seakudo.getselectname().click();
					 Thread.sleep(3000);
					 
					 String sch= seakudo.getpostsearch().getText();
					 System.out.println(sch);
						if(sch.contains("Kushalappa")) {
							 System.out.println("PASS: results are successfully displayed");
						}
						else {
							 System.out.println("FAIL:results are not displayed");
						}
				     
				
						driver.close();
					
					       
					
		}	
				
				
				
}


