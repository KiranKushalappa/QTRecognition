package Automation;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pageobject.QT_login;
import Pageobject.QT_sendkudo;
import resource.base;

public class kudocomment_1_3_3 extends base{
	public static Logger log=LogManager.getLogger(base.class.getName());

	 @Test	
	public void Activepagesndkudo() throws IOException, AWTException 
	{	 
				login_details();
				QT_sendkudo sk =new QT_sendkudo(driver);
				sk.getsendkudo().click();
				sk.getemailid().click();
				sk.getemailid().sendKeys("kushal");
				
				
				Robot m=new Robot();
			     m.keyPress(KeyEvent.VK_DOWN);
			     m.keyPress(KeyEvent.VK_DOWN);
				 m.keyPress(KeyEvent.VK_ENTER);
				 
				sk.getkudo1().click();
				sk.getcomment().sendKeys("");
				sk.getkudosnd().click();
				log.info("Please enter any comment.");
				
				
				driver.close();
				
			}

}


