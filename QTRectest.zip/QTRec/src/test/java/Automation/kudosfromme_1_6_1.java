package Automation;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pageobject.QT_login;
import Pageobject.QT_others;
import Pageobject.QT_searchkudo;
import Pageobject.QT_sendkudo;
import resource.base;

public class kudosfromme_1_6_1 extends base{
	public static Logger log=LogManager.getLogger(base.class.getName());
//Once user clicks on kudos form me option in activity page, he/she should be able to see Kudos sent from him to other employees
	 @BeforeTest	
	public void Activepagesndkudo() throws IOException, AWTException, InterruptedException 
	{	 
				login_details();
				QT_others o=new QT_others(driver);
				o.getkudofromme().click();
				String fromme= o.fromname().getText();
				System.out.println(fromme);
				log.info(fromme);
				
			 Assert.assertEquals(fromme,prop.getProperty("name"));
			 log.info("user is able to see kudos sent from him to other employees");
			 System.out.println("user is able to see kudos sent from him to other employees");
			 driver.close();
				 
				
				}
	 //Once user clicks on kudos to me option in activity page, he/she should be able to see Kudos sent to him form other employees
	 @Test	
		public void Activepagesndkudo1() throws IOException, AWTException, InterruptedException 
		{	 
					login_details();
					QT_others o=new QT_others(driver);
					o.Kudotome().click();
					String tome=o.toname().getText();
					
					 log.info(tome);
					 System.out.println(tome);
				 Assert.assertEquals(tome,prop.getProperty("name"));
				log.info("user is able to see kudos sent to him from other employees");
				 System.out.println("user is able to see kudos sent to him from other employees");
				 driver.close();
					
					}
	//When new kudos sent “Kudos Sent Today” count should increase
	 @Test	
		public void Activepagecount() throws IOException, AWTException, InterruptedException 
		{	 
					login_details();
					
					QT_others o=new QT_others(driver);
					String c1=o.Kudocnt().getText();
				//	System.out.println(c1);
					log.info(c1);
					o.getsendkudo().click();
					o.getemailid().click();
					o.getemailid().sendKeys("Kushalappa Pa (kushalappa.pa@qualitestgroup.com)");
					o.getkudo1().click();
					o.getcomment().sendKeys("goodjob");
					o.getkudosnd().click();
					Thread.sleep(1000);
					o.cancel().click();
					o.getkudofromme().click();
					Thread.sleep(3000);
					String c2=o.Kudocnt().getText();
					Assert.assertNotEquals(c1, c2);
					
					Thread.sleep(3000);
					
					driver.close();	
					
					
		}		   
			//
	 @Test	
		public void Activepagesamekudo() throws IOException, AWTException, InterruptedException 
		{	 
					login_details();
					
					
					
					QT_others o=new QT_others(driver);
					o.getsendkudo().click();
					//o.getemailid().click();
					o.getemailid().sendKeys("Kushalappa Pa (kushalappa.pa@qualitestgroup.com)");
					o.getkudo1().click();
					o.getcomment().sendKeys("goodjob");
					o.getkudosnd().click();
					Thread.sleep(1000);
					o.cancel().click();
					o.getkudofromme().click();
					Thread.sleep(3000);
					String x1=o.fromname().getText();
					System.out.println(x1);
					String x2=o.toname().getText();
					System.out.println(x2);
					//Assert.assertEquals(x1, x2);
					Assert.assertNotEquals(x1, x2);
					
					
					
					 
					driver.close();
					
				}

				
				
			  
			     
			
				
				
				       
				
	}			



